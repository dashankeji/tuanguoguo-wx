var app = getApp();
var wxh = require('../../utils/wxh.js');
Page({
  data: {
    bargain: [],
    url: app.globalData.urlImages,
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
  },
  setTouchMove: function (e) {
    var that = this;
    wxh.home(that, e);
  },
  onLoad: function (options) {

    this.getList();
  },
  getList: function () {
    var that = this;
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    wx.request({
      url: app.globalData.url + '/routine/auth_api/bargain_index?uid=' + app.globalData.uid,
      data: {xiaoben: true},
      method: 'GET',
      header: header,
      success: function (res) {

        if (res.data.data.bargain.length > 0) {
          that.setData({
            bargain: res.data.data.bargain
          })

        };
    
      }
    })
  },
  toProduct: function (e) {
    var that = this;
    var id = e.currentTarget.dataset.id;

    wx.navigateTo({
      url: '/pages/product-con/index?id=' + id
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})