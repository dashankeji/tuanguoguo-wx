// pages/product-con/index.js
var app = getApp();
var wxh = require('../../utils/wxh.js');
var WxParse = require('../../wxParse/wxParse.js');
Page({

    /**
     * 页面的初始数据
     */
    data: {
        CustomBar: app.globalData.CustomBar,
        StatusBar: app.globalData.StatusBar,
        uid: null,
        storeImage: '',//海报产品图
        PromotionCode: '',//二维码图片
        canvasStatus: false,//海报绘图标签
        posterImage:'',//海报路径
        posterImageStatus:false,
        attrName:'',
        attr:'请选择:  ',
        attrValue:'',
        url: app.globalData.urlImages,
        storeInfo: [],
        storeKeyWord:[],
        similarity: [],
        productAttr: [],
        productValue: [],
        likeData: [],
        productSelect:[
            { image: "" },
            { store_name: "" },
            { price: 0 },
            { unique: "" },
            { stock: 0 },
        ],
        reply: [],
        replyCount:0,
        description:'',
        collect:false,//是否收藏
        indicatorDots: true,//是否显示面板指示点;
        autoplay: true,//是否自动播放;
        interval: 3000,//动画间隔的时间;
        duration: 500,//动画播放的时长;
        indicatorColor: "rgba(51, 51, 51, .3)",
        indicatorActivecolor: "#ffffff",
        id:0,
        num: 1,
        show: false,
        prostatus: false,
        CartCount:0,
        status:0,
        offset: 1,
        actionSheetHidden:true,
        IconBack: false,
        XBcanvasTempFilePath: '',
        canvasShareHeight: 300
    },
    onLaunch: function (options) {

    },
    navitorGo: function () {
      var routerArr = getCurrentPages();
      var len = routerArr.length;
 
          if (len - 2 < 0 || routerArr[len - 2].route == 'pages/load/load' || routerArr[len - 2].route == 'pages/loading/loading'){
              wx.switchTab({
                url: '/pages/index/index'
              });
          }else{
              wx.navigateBack({
                delta: 1
              });
          };
    },
    shangPinCodeClick: function () {
      var that = this;
      wx.navigateTo({
        url: '/pages/shangPinCode/index?id=' + that.data.storeInfo.id + '&imgUrl=' + that.data.storeInfo.slider_image[0] + '&store_name=' + that.data.storeInfo.store_name + '&price=' + that.data.storeInfo.price + '&ot_price=' + that.data.storeInfo.ot_price
      });
 
    },
    swiperChange: function (e) {    //轮播监听变化事件
      this.setData({
        currentSwiper: e.detail.current
      })
    },
    setTouchMove: function (e) {
        var that = this;
        wxh.home(that, e);
    },
    goPhone: function () {
        wx.request({
            url: app.globalData.url + '/routine/auth_api/get_site_phone?uid=' + app.globalData.uid,
            method: 'GET',
            success: function (res) {
                wx.makePhoneCall({
                    phoneNumber: res.data.msg,
                })
            }
        })
    },
    setNumber:function(e){
        var that = this;
        var num = parseInt(e.detail.value);
        that.setData({
            num: num ? num : 1
        })
    },
    goCoupon:function(){
        wx.navigateTo({
            url: "/pages/coupon-status/coupon-status"
        })
    },
    getAttrInfo:function(){
        var that = this;
        wxh.footan(that);
        that.setData({
            status:1
        })
    },
    goHomeClick: function () {    //关闭其他页面并返回首页
      wx.switchTab({
        url: '../index/index'
      })
    },
    backClick: function(){
      var that = this;
      wx.navigateBack({
        delta: 1,
        fail: function(err){
          that.setData({
            IconBack: true,
          });
          wx.showToast({
            title: '请点击右下左角的首页返回',
            icon: 'none',
            duration: 1500,
          });
        }
      });
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        var store_id = 0;

        if (options.id) {
          store_id = options.id;
        } else {
          var scene = decodeURIComponent(options.scene);
          scene = scene.split(',');
          app.globalData.spid = scene[0];
          store_id = scene[1];
        };

        /*当前页面因为没有用户信息跳转到获取用户信息时，当获取完后，获取用户信息页面会判断是否有app.globalData.openPages这个值，
          有的话就跳转到设置的页面*/
        app.globalData.openPages = '/pages/product-con/index?id=' + store_id; 

        var that = this;

            that.setData({
              id: store_id,
              uid: app.globalData.uid
            });
        
        if(that.data.uid == null) {
          that.onLoadTwo();
          return;
        }; 

       // that.getCartCount();   根据uid获取用户购物车数量
        var header = {
            'content-type': 'application/x-www-form-urlencoded',
        };
        wx.request({
            url: app.globalData.url + '/routine/auth_api/details?uid=' + app.globalData.uid,
            method: 'POST',
            data:{
                id:that.data.id
            },
            header: header,
            success: function (res) {
                if(res.data.code == 200){
                    var image = "productSelect.image";
                    var store_name = "productSelect.store_name";
                    var price = "productSelect.price";
                    var unique = "productSelect.unique";
                    var stock = "productSelect.stock";
                    that.setData({
                        storeInfo: res.data.data.storeInfo,
                        storeKeyWord: res.data.data.storeInfo.keyword.split(","),
                        similarity: res.data.data.similarity,
                        productAttr: res.data.data.productAttr,
                        productValue: res.data.data.productValue,
                        reply: res.data.data.reply,
                        replyCount: res.data.data.replyCount,
                        //description: res.data.data.storeInfo.description.match(/http[0-9a-z\-\_\.\:\/\\\?\~\@]+\.[a-z]+g/g),
                        collect:res.data.data.storeInfo.userCollect,
                        [image]: res.data.data.storeInfo.image,
                        [stock]: res.data.data.storeInfo.stock,
                        [store_name]: res.data.data.storeInfo.store_name,
                        [price]: res.data.data.storeInfo.price,
                        [unique]: ''
                    })
                  
                    that.likeDataFun();
                    that.onShareAppMessageCanvasImg();
                    WxParse.wxParse('content', 'html', res.data.data.storeInfo.description, that, 0);
                }else{
                    wx.showToast({
                        title: res.data.msg,
                        icon: 'none',
                        duration: 1000
                    });

                }
            }
        });
      wx.request({      //记录在足迹表
        url: app.globalData.url + '/routine/auth_api/InterProductFootprint?uid=' + app.globalData.uid,
        data: { product_id: options.id },
        method: 'GET',
        header: header
      });
    },
  onLoadTwo: function(){
    var that = this;
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    wx.request({
      url: app.globalData.url + '/routine/auth_api/detailsTwo?uid=' + app.globalData.uid,
      method: 'POST',
      data: {
        id: that.data.id,
        xiaoben: true
      },
      header: header,
      success: function (res) {
        if (res.data.code == 200) {
          var image = "productSelect.image";
          var store_name = "productSelect.store_name";
          var price = "productSelect.price";
          var unique = "productSelect.unique";
          var stock = "productSelect.stock";
          that.setData({
            storeInfo: res.data.data.storeInfo,
            storeKeyWord: res.data.data.storeInfo.keyword.split(","),
            similarity: res.data.data.similarity,
            productAttr: res.data.data.productAttr,
            productValue: res.data.data.productValue,
            reply: res.data.data.reply,
            replyCount: res.data.data.replyCount,
            collect: false,
            [image]: res.data.data.storeInfo.image,
            [stock]: res.data.data.storeInfo.stock,
            [store_name]: res.data.data.storeInfo.store_name,
            [price]: res.data.data.storeInfo.price,
            [unique]: ''
          });
          that.onShareAppMessageCanvasImg();
          WxParse.wxParse('content', 'html', res.data.data.storeInfo.description, that, 0);
        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 1000
          });

        }
      }
    });
  },
  listenerActionSheet: function () {
        this.setData({
            actionSheetHidden: !this.data.actionSheetHidden
        })
    },
  likeDataFun: function () {     //猜你喜欢数据请求
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    var that = this;
    wx.request({
      url: app.globalData.url + '/routine/auth_api/getProductFootprint?uid=' + app.globalData.uid,
      data: { limit: 8, offset: 0 },
      method: 'POST',
      header: header,
      success: function (res) {
        
        that.setData({
          likeData: res.data.data
        });
      }
    });
  },
    //替换安全域名
    setDomain:function(url){
        if(url.indexOf("https://") > -1) return url;
        else return url.replace('http://','https://');
    },
    parameterShow: function () {
        var that = this;

      if (that.data.productSelect.unique != '' && that.data.attr == '已选') {  //加个已选判断是确保选中规格后点击确定。因为一选中unique就有值了
            var header = {
                'content-type': 'application/x-www-form-urlencoded',
            };
            wx.request({
                url: app.globalData.url + '/routine/auth_api/set_cart?uid=' + app.globalData.uid,
                method: 'GET',
                data: {
                    productId: that.data.id,
                    cartNum: that.data.num,
                    uniqueId: that.data.productSelect.unique
                },
                header: header,
                success: function (res) {
                    if (res.data.code == 200) {
                        wx.showToast({
                            title: '添加购物车成功',
                            icon: 'success',
                            duration: 2000
                        })
                        wx.switchTab({
                          url: '../buycar/buycar'
                        });
                        
                        /*that.setData({
                            prostatus: false
                        })*/
                        //that.getCartCount();
                     
                    } else {
                        wx.showToast({
                            title: res.data.msg,
                            icon: 'none',
                            duration: 2000
                        })
                    }
                }
            })
        } else {
            wxh.footan(that);
            that.setData({
                status: 2
            })
        }
    },
    goOrder: function () {
      app.setUserInfo();
      if(app.globalData.uid == null) return;
        var that = this;
        if (that.data.productSelect.unique != '' && that.data.attr == '已选') {
            var header = {
                'content-type': 'application/x-www-form-urlencoded',
            };
            wx.request({
                url: app.globalData.url + '/routine/auth_api/now_buy?uid=' + app.globalData.uid,
                method: 'GET',
                data: {
                    productId: that.data.id,
                    cartNum: that.data.num,
                    uniqueId: that.data.productSelect.unique
                },
                header: header,
                success: function (res) {
                    if (res.data.code == 200) {
                        wx.navigateTo({ //跳转至指定页面并关闭其他打开的所有页面（这个最好用在返回至首页的的时候）
                            url: '/pages/order-confirm/order-confirm?id=' + res.data.data.cartId
                        })
                    } else {
                        wx.showToast({
                            title: res.data.msg,
                            icon: 'none',
                            duration: 2000
                        })
                    }
                }
            })
        } else {
            wxh.footan(that);
            that.setData({
                status: 3
            })
        }
    },
    modelbg: function (e) {
        this.setData({
            prostatus: false
        })
    },
    bindMinus: function () {
        var that = this;
        wxh.carmin(that)
    },
    bindPlus: function () {
        var that = this;
        wxh.carjia(that);
    },
    tapsize: function (e) {
        var that = this;
        var key = e.currentTarget.dataset.key;
        var attrValues = [];
        var attrName = that.data.attrName;
        var attrNameArr = attrName.split(",");
        var array = that.data.productAttr;
        for (var i in that.data.productAttr){
            for (var j in that.data.productAttr[i]['attr_values']){
                if (that.data.productAttr[i]['attr_values'][j] == key){
                    attrValues = that.data.productAttr[i]['attr_values'];
                }
            }
        }
        for (var ii in attrNameArr) {
            if (that.in_array(attrNameArr[ii],attrValues)){
                attrNameArr.splice(ii, 1);
            }
        }
        attrName = attrNameArr.join(',');
        if (attrName) var eName = e.currentTarget.dataset.key + ',' + attrName;
        else var eName = e.currentTarget.dataset.key;
        attrNameArr = eName.split(",");
        var isBool = false;
        var isattrNameArrLength = 0;
        for (var an in attrNameArr) {
            if (attrNameArr[an]) isattrNameArrLength = isattrNameArrLength + 1;
        }
        for (var b in that.data.productValue) {
            var sukValue = that.data.productValue[b].suk.split(",");
            if (sukValue.length == isattrNameArrLength) {
                if (that.in_array_two(attrNameArr, sukValue)) {
                    isBool = true;
                }
            } else {
                isBool = true;
            }
        }
        if (!isBool){
            wx.showToast({
                title: '属性不存在，请重新选择',
                icon: 'none',
                duration: 1500,
            })
        } else {
            that.setData({
                attrName: e.currentTarget.dataset.key + ',' + attrName
            })
            attrNameArr = that.data.attrName.split(",");
            var attrNameArrSort = '';
            for (var jj in that.data.productAttr) {
                for (var jjj in that.data.productAttr[jj]['attr_values']) {
                    if (that.in_array(that.data.productAttr[jj]['attr_values'][jjj], attrNameArr)) {
                        attrNameArrSort += that.data.productAttr[jj]['attr_values'][jjj] + ',';
                    }
                }
            }
            for (var jj in array) {
                for (var jjj in array[jj]['attr_values']) {
                    if (that.in_array(array[jj]['attr_values'][jjj], attrNameArr)) {
                        array[jj]['attr_value'][jjj].check = true;
                    } else {
                        array[jj]['attr_value'][jjj].check = false;
                    }
                }
            }
            that.setData({
                productAttr: array
            })
            var attrNameArrSortArr = attrNameArrSort.split(",");
            attrNameArrSortArr.pop();
            that.setData({
                attrName: attrNameArrSortArr.join(',')
            })
            var arrAttrName = that.data.attrName.split(",");
            for (var index in that.data.productValue) {
                var strValue = that.data.productValue[index]['suk'];
                var arrValue = strValue.split(",");
                if (that.in_array_two(arrValue, arrAttrName)) {
                    var image = "productSelect.image";
                    var store_name = "productSelect.store_name";
                    var price = "productSelect.price";
                    var unique = "productSelect.unique";
                    var stock = "productSelect.stock";
                    that.setData({
                        [image]: that.data.productValue[index]['image'],
                        [price]: that.data.productValue[index]['price'],
                        [unique]: that.data.productValue[index]['unique'],
                        [stock]: that.data.productValue[index]['stock'],
                    })
                }
            }
        }
    },
    in_array_two:function(arr1,arr2){
        if (arr1.sort().toString() == arr2.sort().toString()) {
            return true;
        }
        else {
            return false;
        }

    },
    in_array: function (str, arr) {
        for (var f1 in arr) {
            if (arr[f1] == str) {
                return true;
            }
        }
    },
    tapcolor: function (e) {
        var that = this;
        wxh.tapcolor(that, e);
    },
    subBuy:function(e){
      app.setUserInfo();
      if(app.globalData.uid == null) return;

        wx.request({
            url: app.globalData.url + '/routine/auth_api/get_form_id?uid=' + app.globalData.uid,
            method: 'GET',
            data: {
                formId: e.detail.formId
            },
            success: function (res) {}
        })
        var that = this;
        if (that.data.num > that.data.productSelect.stock){
            wx.showToast({
                title: '库存不足' + that.data.num,
                icon: 'none',
                duration: 2000
            })
            that.setData({
                num: that.data.productSelect.stock,
            })
        } else if (that.data.productAttr.length > 0 && that.data.productSelect.unique == '') {
            wx.showToast({
                title: '请选择属性',
                icon: 'none',
                duration: 2000
            })
        }else{
            if (that.data.status == 1){
                var attrValueData = [];
                for (var i in that.data.productValue){
                    if (that.data.productValue[i].unique == that.data.productSelect.unique) {
                        for (var j in that.data.productAttr) {
                            for (var k in that.data.productAttr[j].attr_values) {
                                var sukArr = that.data.productValue[i].suk.split(',');
                                if (that.in_array(that.data.productAttr[j].attr_values[k], sukArr)){
                                    attrValueData.push(that.data.productAttr[j].attr_name + ':' + that.data.productAttr[j].attr_values[k]) ;

                                }
                            }
                        }

                    }
                }
            
                that.setData({
                    attr:'已选',
                    attrValue: attrValueData.join(','),
                    prostatus: false
                });
             
            }else if (that.data.status == 2) {
             // console.log(3333,that.data.productSelect.unique)
                var header = {
                    'content-type': 'application/x-www-form-urlencoded',
                };
                wx.request({
                    url: app.globalData.url + '/routine/auth_api/set_cart?uid=' + app.globalData.uid,
                    method: 'GET',
                    data: {
                        productId: that.data.id,
                        cartNum: that.data.num,
                        uniqueId: that.data.productSelect.unique
                    },
                    header: header,
                    success: function (res) {
                        if (res.data.code == 200) {
                            wx.showToast({
                                title: '添加购物车成功',
                                icon: 'success',
                                duration: 2000
                            })
                           wx.switchTab({
                            url: '../buycar/buycar'
                           });
                            /*that.setData({
                                prostatus: false
                            })*/
                           // that.getCartCount();
                        } else {
                            wx.showToast({
                                title: res.data.msg,
                                icon: 'none',
                                duration: 2000
                            })
                        }
                    }
                })
            } else if (that.data.status == 3){
                var header = {
                    'content-type': 'application/x-www-form-urlencoded',
                };
                wx.request({
                    url: app.globalData.url + '/routine/auth_api/now_buy?uid=' + app.globalData.uid,
                    method: 'GET',
                    data: {
                        productId: that.data.id,
                        cartNum: that.data.num,
                        uniqueId: that.data.productSelect.unique
                    },
                    header: header,
                    success: function (res) {
                        if (res.data.code == 200) {
                            wx.navigateTo({ //跳转至指定页面并关闭其他打开的所有页面（这个最好用在返回至首页的的时候）
                                url: '/pages/order-confirm/order-confirm?id=' + res.data.data.cartId
                            })
                        } else {
                            wx.showToast({
                                title: res.data.msg,
                                icon: 'none',
                                duration: 2000
                            })
                        }
                    }
                })
            }
        }
    },
    getCartCount:function(){
        var that = this;
        var header = {
            'content-type': 'application/x-www-form-urlencoded',
        };
        wx.request({
            url: app.globalData.url + '/routine/auth_api/get_cart_num?uid=' + app.globalData.uid,
            method: 'POST',
            header: header,
            success: function (res) {
                that.setData({
                    CartCount: res.data.data
                })
            }
        })
    },
    setCollect:function(){
        if (this.data.collect) this.unCollectProduct();
        else this.collectProduct();
    },
    unCollectProduct: function () {
        var that = this;
        var header = {
            'content-type': 'application/x-www-form-urlencoded',
        };
        wx.request({
            url: app.globalData.url + '/routine/auth_api/uncollect_product?uid=' + app.globalData.uid,
            method: 'POST',
            header: header,
            data: {
                productId: that.data.id
            },
            success: function (res) {
                wx.showToast({
                    title: '取消收藏成功',
                    icon: 'success',
                    duration: 1500,
                })
                that.setData({
                    collect: false,
                })
            }
        })
    },
    collectProduct:function(){
        var that = this;
        var header = {
            'content-type': 'application/x-www-form-urlencoded',
        };
        wx.request({
            url: app.globalData.url + '/routine/auth_api/collect_product?uid=' + app.globalData.uid,
            method: 'POST',
            header: header,
            data:{
                productId:that.data.id
            },
            success: function (res) {
                wx.showToast({
                    title: '收藏成功',
                    icon: 'success',
                    duration: 1500,
                })
                that.setData({
                    collect: true,
                })
            }
        })
    },
    getCar:function(){
        wx.switchTab({
            url: '/pages/buycar/buycar'
        });
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
      this.setData({
        IconBack: false,
      });
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
      var that = this;
      var limit = 8;
      var offset = limit * that.data.offset++;

      var header = {
        'content-type': 'application/x-www-form-urlencoded',
      };
      wx.request({
        url: app.globalData.url + '/routine/auth_api/getProductFootprint?uid=' + app.globalData.uid,
        data: { limit: limit, offset: offset },
        method: 'POST',
        header: header,
        success: function (res) {
          var len = res.data.data.length;

          if (len < 1) {
            --that.data.offset;
            wx.showToast({
              title: '数据已经加载到尽头了',
              icon: 'none',
              duration: 2000
            });
            return false;
          };
          
          that.data.likeData = that.data.likeData.concat(res.data.data);
          that.setData({
            likeData: that.data.likeData
          });

        },
        fail: function (res) {
          console.log('submit fail');
        },
        complete: function (res) {
          console.log('submit complete');
        }
      });
    },
    
    //  分享图片生成
    onShareAppMessageCanvasImg: function() {
      var that = this;

      wx.downloadFile({
        url: that.data.storeInfo.image,
        success: function (res) {
          
          if (res.statusCode === 200) {    
               
            wx.getSystemInfo({
              success: function (resTwo) {
                var width = resTwo.windowWidth;
                var height = ~~((width / 5) * 4);

                that.setData({
                  canvasShareHeight: height
                });

                const ctx = wx.createCanvasContext('myCanvasTwo');
                      ctx.drawImage(res.tempFilePath, 0, 0, width, height);
                
                const grd = ctx.createLinearGradient(0, 0, 500, 0)
                      grd.addColorStop(0, 'red');
                      grd.addColorStop(0.3, 'red')
                      grd.addColorStop(1, 'rgb(253, 151, 48)');
                      ctx.setFillStyle(grd);
                      ctx.fillRect(0, 0, width, 40);

                      ctx.font = 'normal bold 16px sans-serif';
                      ctx.setFillStyle('white');
                      ctx.setTextAlign('left');
                      ctx.fillText("￥", 10, 25);

                      ctx.font = 'normal bold 23px sans-serif';
                      ctx.setFillStyle('white');
                      ctx.setTextAlign('left');
                      ctx.fillText(that.data.storeInfo.price, 25, 27);

                      var priceWidth = ctx.measureText(that.data.storeInfo.price).width;

                      ctx.font = 'normal bold 16px sans-serif';
                      ctx.setFillStyle('white');
                      ctx.setTextAlign('left');
                      ctx.fillText('￥' + that.data.storeInfo.ot_price, ctx.measureText('￥').width + 5 + priceWidth + 15, 26);

                      var otPriceWidth = ctx.measureText('￥ ' + that.data.storeInfo.ot_price).width;

                      ctx.moveTo(ctx.measureText('￥').width + 5 + priceWidth + 15, 26 - 5)
                      ctx.lineTo(otPriceWidth + 100, 26 - 5)
                      ctx.setStrokeStyle('#fff')
                      ctx.stroke()

                      ctx.font = 'normal bold 16px sans-serif';
                      ctx.setFillStyle('#1C1C1C');
                      ctx.setTextAlign('right');
                      ctx.fillText('已售' + (that.data.storeInfo.ficti + that.data.storeInfo.sales) + that.data.storeInfo.unit_name, width - 50, 25);

                      ctx.draw(false, function () {
                        wx.canvasToTempFilePath({
                          canvasId: 'myCanvasTwo',
                          success: function (res) {
                            that.setData({
                                XBcanvasTempFilePath: res.tempFilePath
                              });
                          },
                          fail: function (res) {
                            wx.showToast({
                              title: res.errMsg,
                              icon: 'none',
                              duration: 2000
                            })
                          }
                        });
                });

              }
           });            

          } else {
            wx.showToast({
              title: 商品图片 + '下载失败！',
              icon: 'none',
              duration: 2000,
            });
          };
        }
      });

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {
        var that = this;
        that.setData({
          actionSheetHidden: !that.data.actionSheetHidden
        });      

        var XBcanvasTempFilePath = that.data.XBcanvasTempFilePath;

        if (!XBcanvasTempFilePath){
          wx.showModal({
            title: '分享提示',
            content: '分享图片还没有生成,当前使用的是默认分享图片',
            icon: 'none',
            duration: 2000
          })
        };

        return {
            title: that.data.productSelect.store_name,
            path: app.globalData.openPages,
            imageUrl: XBcanvasTempFilePath || that.data.storeInfo.image,
            success: function () {
                wx.showToast({
                    title: '分享成功',
                    icon: 'success',
                    duration: 2000
                })
            }
        };
    }
})