// pages/address/address.js
var app = getApp();
Page({
  data: {
    cartId: 0,
    pinkId: '',
    couponId: '',
    addressArray:[],
    searchValue: '',
  },
  bindinput: function(e) {
     this.setData({
       searchValue: e.detail.value
     });
  },
  bindConfirm: function() {

    var that = this;
    var addressList = [];

    if(that.data.searchValue.length > 0){
        for(var i = 0; i < that.data.addressArrayTwo.length; i++){
          var address = that.data.addressArrayTwo[i].province + that.data.addressArrayTwo[i].city + that.data.addressArrayTwo[i].district + that.data.addressArrayTwo[i].detail;
              if(address.indexOf(that.data.searchValue) != -1){
                addressList.push(that.data.addressArrayTwo[i]);
              };
        };
  }else{
      addressList = that.data.addressArrayTwo;
  };

        that.setData({
          addressArray: addressList
        });
  },
  onLoad: function (options) {
    var that = this;

        if (options.cartId) {
            that.data.cartId = options.cartId;
            that.data.pinkId = options.pinkId;
            that.data.couponId = options.couponId;
          };
  },
  onShow: function(){
    this.getAddressTwo();
  },
  tellFun: function(e){
    wx.makePhoneCall({
      phoneNumber: e.currentTarget.dataset.phone 
    });
  },
  goNavaitor: function(e){
    let plugin = requirePlugin('routePlan');
    let key = 'RVABZ-VQPCF-ZAVJS-NMULA-6RPD2-PIBEL';  //使用在腾讯位置服务申请的key
    let referer = '大山科技';   //调用插件的app的名称
    var that = this;
    let endPoint = JSON.stringify({  //终点
      'name': e.currentTarget.dataset.detail,
      'latitude': e.currentTarget.dataset.latitude,
      'longitude': e.currentTarget.dataset.longitude
    });
    wx.navigateTo({
      url: 'plugin://routePlan/index?key=' + key + '&referer=' + referer + '&endPoint=' + endPoint
    });
  },
  getAddressTwo: function(){
    var that = this;
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    wx.request({
      url: app.globalData.url + '/routine/auth_api/get_all_ztaddress?uid=' + app.globalData.uid + '&xiaoben=true',
      method: 'GET',
      header: header,
      success: function (res) {
        if (res.data.code == 200) {
          that.setData({
            addressArray: res.data.data,
            addressArrayTwo: res.data.data
          });
        };
      }
    });
  },
  activetapTwo: function (e) {

    var id = e.target.dataset.idx;
    var that = this;
            
            if (that.data.cartId) {

              var cartId = that.data.cartId;
              var pinkId = that.data.pinkId;
              var couponId = that.data.couponId;
              
              that.data.cartId = '';
              that.data.pinkId = '';
              that.data.couponId = '';

              wx.redirectTo({ //关闭当前页面，跳转到应用内的某个页面
                url: '/pages/order-confirm/order-confirm?id=' + cartId + '&distributionMode=ziti' + '&addressId=' + id + '&pinkId=' + pinkId + '&couponId=' + couponId
              })
            };
        
  }
})