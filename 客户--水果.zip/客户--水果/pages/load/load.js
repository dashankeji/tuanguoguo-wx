var app = getApp();
Page({
  data: {
    logo: '',
    name: '',
    url: app.globalData.url,
    LoginDisabled: false
  },
  onLoad: function (options) {
    var that = this;
  },
  backHomePage: function () {
    wx.switchTab({
      url: '/pages/index/index'
    })
  },
  getEnterLogo: function () {
    var that = this;
    wx.request({
      url: app.globalData.url + '/routine/login/get_enter_logo',
      method: 'post',
      dataType  : 'json',
      success: function (res) {
        that.setData({
          logo: res.data.data.site_logo,
          name: res.data.data.site_name
        })
      }
    })
  },
  //获取用户信息并且授权
  getUserInfo: function(e){
    var userInfo = e.detail.userInfo;
    var that = this;

    if (!userInfo) {
      wx.showToast({
        title: "获取用户授权信息失败",
        icon: 'none',
        duration: 2000
      });
      return;
    };
       
    userInfo.spid = app.globalData.spid;
    wx.login({
      success: function (res) {
       
        if (res.code) {
          wx.showLoading({
            title: '登录中',
          });
          that.setData({
            LoginDisabled: true
          });

          userInfo.code = res.code;
          wx.request({
            url: app.globalData.url + '/routine/login/index',
            method: 'post',
            dataType  : 'json',
            data: {
              info: userInfo
            },
            success: function (res) {
              wx.hideLoading();

              if(res.data.code == 200){
                app.globalData.uid = res.data.data.uid;
                app.globalData.openid = res.data.data.routine_openid;

                wx.showModal({
                  title: '提示',
                  content: '登录成功',
                  cancelText: '返回我的',
                  confirmText: '返回首页',
                  cancelColor: '#1E90FF',
                  confirmColor: '#1E90FF',
                  success(res) {
                    if (res.confirm) {
                      wx.switchTab({
                        url: '/pages/index/index'
                      });
                    } else if (res.cancel) {
                      wx.switchTab({
                        url: '/pages/user/user'
                      });
                    };
                  }
                });
              }else{
                wx.showModal({
                  title: '提示',
                  content: '登录失败',
                });
              };

              that.setData({
                LoginDisabled: false
              });
        
            },
            fail: function(){
              wx.showModal({
                title: '提示',
                content: '登录失败，请重试'
              });
              that.setData({
                LoginDisabled: false
              });
            }
          });
        } else {
          console.log('获取code失败' + res.errMsg);
          wx.showToast({
            title: "获取code失败",
            icon: 'none',
            duration: 2000
          });
        }
      },
      fail: function () {
        wx.showToast({
          title: "获取code失败",
          icon: 'none',
          duration: 2000
        });
      },
    })
  },
})