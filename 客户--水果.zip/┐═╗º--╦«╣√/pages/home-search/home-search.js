// pages/home-search/x.js
var app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    CustomBar: app.globalData.CustomBar,
    StatusBar: app.globalData.StatusBar,
    inputText: '',      //input框的文本值存储
    ActiveId: 0,     //全部分类里当前点击的分类存储
    priceText: 'asc',      //当前点击的价格排序存储
    content: [],        //要显示哪个下拉菜单数据
    priceContent: [{ type: 'asc', value: '价格从低到高' }, { type: 'desc', value: '价格从高到低' }],              //价格下拉菜单数据
    allArcitveContent: [],         //全部分类下拉菜单数据
    pxopen: false,
    priceClickFlag: false,      //判断上个点击是否为价格
    PriceIndex: -1,
    ActiveIndex: -1,
    startpage: 0,
    limit: 10,
    cid: 0,
    shoppingData: [],
    PriceCF: '价格',
    ProductCF: '全部分类',
    hidden: true,
    offset: 1,
    inputJSON: {
      status: 1,
      text: ''
    }
  },

  shoppingReq: function (keyword) {
    var that = this;
    wx.request({
      url: app.globalData.url + '/routine/auth_api/get_product_list?uid=' + app.globalData.uid,
      data: { sid: this.data.ActiveId, cid: this.data.cid, priceOrder: this.data.priceText, salesOrder: '', news: this.data.news, first: this.data.startpage, keyword: keyword, limit: this.data.limit },
      method: 'GET',
      success: function (res) {
        if (res.data.code == 200) {
          var len = res.data.data.length;
          that.setData({
            shoppingData: res.data.data,
            hidden: false
          });
          wx.showToast({
            title: '数据获取完成',
            icon: 'none',
            duration: 2000
          });
        }
      },
      fail: function (res) {
        console.log('submit fail');
      },
      complete: function (res) {
        console.log('submit complete');
      }
    })
  },
  ClassificationListReqID: function (arr, arrName) {    //获取分类id
    for (var i = 0; i < arr.length; i++) {
      if (arr[i].cate_name == arrName[0] && arrName.length == 1) {
        return arr[i].id;
      }
      if (arr[i].cate_name == arrName[0] && arr[i].child) {
        arrName.splice(0, 1);
        return this.ClassificationListReqID(arr[i].child, arrName);
      }
    }
    return -1;
  },
  ClassificationListReqChild: function (arr, arrName) {    //获取分类child
    for (var i = 0; i < arr.length; i++) {
      if (arr[i].cate_name == arrName[0] && arrName.length == 1) {
        return arr[i].child;
      }
      if (arr[i].cate_name == arrName[0] && arr[i].child) {
        arrName.splice(0, 1);
        return this.ClassificationListReqChild(arr[i].child, arrName);
      }
    }
    return -1;
  },
  ClassificationListReq: function () {

    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    var that = this;
    wx.request({
      url: app.globalData.url + '/routine/auth_api/get_product_category?uid=' + app.globalData.uid,
      method: 'POST',
      header: header,
      success: function (res) {

        var arr = that.ClassificationListReqChild(res.data.data, ['分类']);
        var id = that.ClassificationListReqID(res.data.data, ['分类']);
        that.data.cid = id;
        arr.unshift({ id: 0, cate_name: '全部分类' });

        that.shoppingReq('');
        that.setData({
          allArcitveContent: arr
        });

      }
    });
  },

  searchClick: function () {
    var inputtext = this.data.inputText.replace(/\s+/g, "")
    if (inputtext.length < 1) {
      wx.showToast({
        title: '请输入关键字',
        icon: 'none',
        duration: 1000
      });
      inputtext = '';
    };
    this.data.offset = 1;
    this.data.inputJSON.status = 1;
    this.shoppingReq(inputtext);
  },

  bindkeyblur: function (e) {
    this.data.inputText = e.detail.value;
  },

  listPrice: function (e) {     //价格按钮    
    
    if (this.data.pxopen && this.data.priceClickFlag) {
      this.setData({
        pxopen: false,
      })
    } else {
      this.setData({
        pxopen: true,
        content: this.data.priceContent,
        priceClickFlag: true
      })
    };

  },

  listAll: function () {        //全部分类按钮

    if (this.data.pxopen && !this.data.priceClickFlag) {
      this.setData({
        pxopen: false,
      })
    } else {
      this.setData({
        pxopen: true,
        content: this.data.allArcitveContent,
        priceClickFlag: false
      })
    };
  },

  ActiveClick: function (e) {     //全部分类里的分类的点击
    this.data.offset = 1;

    this.setData({
      ActiveId: e.currentTarget.dataset.id,
      pxopen: false,
      ActiveIndex: e.currentTarget.dataset.index,
      ProductCF: e.currentTarget.dataset.value,
      inputText: ''
    });
    this.shoppingReq('');
  },

  PriceClick: function (e) {        //价格里的下拉菜单值点击
    this.data.offset = 1;

    this.setData({
      priceText: e.currentTarget.dataset.type,
      pxopen: false,
      PriceIndex: e.currentTarget.dataset.index,
      PriceCF: e.currentTarget.dataset.value,
      inputText: ''
    });
    this.shoppingReq('');
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    app.setUserInfo();
    if (app.globalData.uid == null) return;
    this.ClassificationListReq();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this;
    if (that.data.hidden) return;

    that.setData({
      hidden: true,
    });

    var offset = 10 * that.data.offset++;

      if( that.data.inputJSON.status == 1 ){
        that.data.inputJSON.status = 0;
        that.data.inputJSON.text = that.data.inputText.replace(/\s+/g, "");
      };

    wx.request({
      url: app.globalData.url + '/routine/auth_api/get_product_list?uid=' + app.globalData.uid,
      data: { sid: that.data.ActiveId, cid: that.data.cid, priceOrder: that.data.priceText, salesOrder: '', news: that.data.news, first: offset, keyword: that.data.inputJSON.text, limit: 10 },
      method: 'GET',
      success: function (res) {
        if (res.data.code == 200) {
          var len = res.data.data.length;

          if (len.length < 1) {
            --that.data.offset;
            wx.showToast({
              title: '没有更多的商品了',
              icon: 'none',
              duration: 2000
            })
          } else {
            wx.showToast({
              title: '数据获取完成',
              icon: 'none',
              duration: 2000
            });
            that.data.shoppingData = that.data.shoppingData.concat(res.data.data);
          };

          that.setData({
            hidden: false,
            shoppingData: that.data.shoppingData
          });
         
        }
      },
      fail: function (res) {
        console.log('submit fail');
      },
      complete: function (res) {
        console.log('submit complete');
      }
    });
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})