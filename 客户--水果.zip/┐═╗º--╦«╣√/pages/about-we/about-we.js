var WxParse = require('../../wxParse/wxParse.js');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  getAboutWeContent: function () {    //根据id请求关于我们图文信息
    var that = this;
    wx.request({
      url: app.globalData.url + '/routine/auth_api/visit?uid=' + app.globalData.uid + '&xiaoben=true',
      method: 'GET',
      data: {
        id: 15,
      },
      success: function (res) {
        that.setData({
          backNavTitle: res.data.data.author
        })

        WxParse.wxParse('content', 'html', res.data.data.image_inputstwo_title, that, 0);

      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getAboutWeContent();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})