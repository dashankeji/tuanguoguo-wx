// pagestwo/wodepintuan/wodepintuan.js
var app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
      WDpintuanData: [],
      hidden: true,
      offset: 1
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    app.setUserInfo();
    if(app.globalData.uid == null) return;
    var that = this;
        that.reqGetWDPintuanList();
  },
  reqGetWDPintuanList:function() {
    var that = this;
        wx.request({
          url: app.globalData.url + '/routine/auth_api/get_user_order_list?uid=' + app.globalData.uid,
          method: 'GET',
          data: {
            type: 11,
            first: 0,
            limit: 8,
            search: ''
          },
          success: function (res) {
            if(res.data.code == 200){
                that.setData({
                    WDpintuanData: res.data.data,
                    hidden: false
                });
            }else{
                wx.showToast({
                  title: '数据获取失败'
                });
            }
          }
        });
  },
  lookPintuanClick: function(e) {
       wx.navigateTo({
         url: '/pages/join-pink/index?id=' + e.currentTarget.dataset.id,
       })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this;
    if (that.data.hidden) return;
        that.setData({
          hidden: true
        });

    var offset = 8 * that.data.offset++;
    wx.request({
      url: app.globalData.url + '/routine/auth_api/get_user_order_list?uid=' + app.globalData.uid,
      method: 'GET',
      data: {
        type: 11,
        first: offset,
        limit: 8,
        search: ''
      },
      success: function (res) {
        var data = res.data.data;
        if (res.data.code == 200) {

          if (data.length < 1) {
            --that.data.offset;
            wx.showToast({
              title: '没有更多的商品了',
              icon: 'none',
              duration: 2000
            })
          } else {
            that.data.WDpintuanData = that.data.WDpintuanData.concat(data);
          };

          that.setData({
            WDpintuanData: that.data.WDpintuanData,
            hidden: false
          });
        } else {
          wx.showToast({
            title: '数据获取失败'
          });
        }
      }
    });
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})