//index.js
//获取应用实例
var app = getApp();

Page({
  /**
   * 页面的初始数据
   */
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    currentSwiper: 0,   //轮播焦点
    currentSwiperTwo: 0, //商品轮播焦点
    url: app.globalData.urlImages,
    imgUrls:[],
    menus:[],
    indicatorDots: true,//是否显示面板指示点;
    autoplay: true,//是否自动播放;
    interval: 3000,//动画间隔的时间;
    duration: 500,//动画播放的时长;
    indicatorColor: "rgba(51, 51, 51, .3)",
    indicatorActivecolor: "#ffffff",
    offset: 1,
    title: "玩命加载中...",
    hidden: false,
    cateIdOne: -1,
    cateIdTwo: -2,
    shoppingBanner: [],
    justone: [],
    seckill: [],
    selected: [],
    SelectedBanner: [],
    AssembleBanner: [],
    SeckillBanner: [],
    SpecialPurchaseBanner: [],
    /**
     * 走马灯
     */
    text: '应召小程序内用户帐号登录规范调整和优化建议,需要把用户登录改为引导方式，望见谅下',
    marqueePace: .5, //滚动速度
    marqueeDistance: 0, //初始滚动距离
    marqueeDistance2: 0,
    marquee2copy_status: false,
    marquee2_margin: 60,
    size: 14,
    orientation: 'left', //滚动方向
    intervalTwo: 20, // 时间间隔
    scrollLeft: 0,     //拼团列表left
    TabCur: 0,          //拼团列表选择了那个
    CombinationList: [],      //拼团数据
    timeer: null,
  },
  gonavigtor() {
    wx.getLocation({//获取当前经纬度
      type: 'wgs84', //返回可以用于wx.openLocation的经纬度，官方提示bug: iOS 6.3.30 type 参数不生效，只会返回 wgs84 类型的坐标信息  
      success: function (res) {
        wx.openLocation({//​使用微信内置地图查看位置。
          latitude: 22.5542080000,//要去的纬度-地址
          longitude: 113.8878770000,//要去的经度-地址
          name: "宝安中心A地铁口",
          address: '宝安中心A地铁口'
        })
      }
    })
  },
  tabSelect(e) {     //拼团列表点击事件
    this.setData({
      TabCur: e.currentTarget.dataset.id,
      scrollLeft: (e.currentTarget.dataset.id - 1) * 60
    })
  },
  swiperChange: function (e) {    //轮播监听变化事件
    this.setData({
      currentSwiper: e.detail.current
    })
  },
  swiperChangeTwo: function (e) {    //商品轮播轮播监听变化事件
    this.setData({
      currentSwiperTwo: e.detail.current
    });
  },
  goUrl:function(e){
    if (e.currentTarget.dataset.url != '#'){
      wx.navigateTo({
        url: e.currentTarget.dataset.url,
      })
    }
  },
  getArticleBanner: function () {
    var that = this;
    wx.request({
      url: app.globalData.url + '/routine/auth_api/get_article_banner?uid=' + app.globalData.uid + '&cid=2&xiaoben=true',
      method: 'GET',
      success: function (res) {
        that.setData({
          shoppingBanner: res.data.data
        });
      }
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    if (options.spid){
      app.globalData.spid = options.spid;
    };

    if (options.scene) app.globalData.spid = options.scene;

    that.ClassificationListReq();
    that.getCombinationList();

  },
  getCombinationList: function(){
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    var that = this;
    wx.request({
      url: app.globalData.url + '/routine/auth_api/get_combination_list?uid=' + app.globalData.uid + '&xiaoben=true',
      data: {
        offset: 0,
        limit: 3
      },
      method: 'GET',
      header: header,
      success: function (res) {
          that.setData({
            CombinationList: res.data.data
          });
      }
    });

  },
  timeFormat(param) {//小于10的格式化函数
    return param < 10 ? '0' + param : param;
  },
  seckillFun: function (){
    var that = this;
    that.data.timeer = setInterval(function(){

      var seckill = that.data.seckillTwo;
      for (var k = 0; k < seckill.length; k++) {

        var stop_time = seckill[k].stop_time;
        var nowTime = new Date().getTime() / 1000;

        var time = stop_time - nowTime;

        if (time > 0) {
          var day = parseInt(time / (60 * 60 * 24));
          var hou = parseInt(time % (60 * 60 * 24) / 3600);
          var min = parseInt(time % (60 * 60 * 24) % 3600 / 60);
          var sec = parseInt(time % (60 * 60 * 24) % 3600 % 60);
          hou = parseInt(hou) + parseInt(day * 24);

          seckill[k].XB_stopTime = '' + that.timeFormat(hou) + ':' + that.timeFormat(min) + ':' + that.timeFormat(sec) + ' 结束';
        } else {
          clearInterval(that.data.timeer);
          seckill[k].XB_stopTime = '00:00:00' + ' 结束';
        };

      };

      that.setData({
        seckill: seckill
      });

    },1000);
  },
  getIndexInfo: function (cateIdOne, cateIdTwo, cateIdThree, cateIdFour){
    var cateIdOne = cateIdOne ||  -1;
    var cateIdTwo = cateIdTwo || -1;
    var cateIdThree = cateIdThree || -2;
    var cateIdFour = cateIdFour || -1;

    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    var that = this;
    wx.request({
      url: app.globalData.url + '/routine/auth_api/index?uid=' + app.globalData.uid + '&cateId_one=' + cateIdOne + '&cateId_two=' + cateIdTwo + '&cateId_Three=' + cateIdThree + '&cateId_Four=' + cateIdFour + '&xiaoben=true',
      method: 'POST',
      header: header,
      success: function (res) {
        //  截取跳转路径
        var bannerData = res.data.data.banner;
        for (var i = 0; i < bannerData.length; i++){
          if (bannerData[i].url){
            bannerData[i].url = bannerData[i].url.split('—')[1];
          };
        };

        var menusData = res.data.data.menus;
        for (var j = 0; j < menusData.length; j++) {
          if (menusData[j].url) {
            menusData[j].url = menusData[j].url.split('—')[1];
          };
        };

        //  求出秒杀商品结束时间
        that.data.seckillTwo = res.data.data.seckill;
        that.seckillFun();

        that.setData({
          imgUrls: bannerData, //轮播
          menus: menusData,//导航
          SpecialPurchaseBanner: res.data.data.SpecialPurchaseBanner,
          SeckillBanner: res.data.data.SeckillBanner,
          AssembleBanner: res.data.data.AssembleBanner,
          SelectedBanner: res.data.data.SelectedBanner,
          justone: res.data.data.bargain,    //  特价购商品列表
          selected: res.data.data.best   //  精选产品列表
        });

      }
    })
  },
  ClassificationListReqID: function (arr, arrName) {    //获取分类id
    for (var i = 0; i < arr.length; i++){
      if (arr[i].cate_name == arrName[0] && arrName.length == 1){
        return arr[i].id;
      } 
      if (arr[i].cate_name == arrName[0] && arr[i].child ){
         arrName.splice(0,1);
        return this.ClassificationListReqID(arr[i].child,arrName);
      }
    }
    return -1;
  },
  ClassificationListReqChild: function (arr, arrName) {    //获取分类child
    for (var i = 0; i < arr.length; i++) {
      if (arr[i].cate_name == arrName[0] && arrName.length == 1) {
        return arr[i].child;
      }
      if (arr[i].cate_name == arrName[0] && arr[i].child) {
        arrName.splice(0, 1);
        return this.ClassificationListReqChild(arr[i].child, arrName);
      }
    }
    return -1;
  },
  ClassificationListReq: function () {
   
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    var that = this;
    wx.request({
      url: app.globalData.url + '/routine/auth_api/get_product_category?uid=' + app.globalData.uid + '&xiaoben=true',
      method: 'POST',
      header: header,
      success: function (res) {
        var SpecialPurchaseBannerCateId, SeckillBannerCateId, AssembleBannerCateId, SelectedBannerCateId;

            SpecialPurchaseBannerCateId = that.ClassificationListReqID(res.data.data, ['首页', '特价购', '广告图']);
            SeckillBannerCateId = that.ClassificationListReqID(res.data.data, ['首页', '秒杀', '广告图']);
            AssembleBannerCateId = that.ClassificationListReqID(res.data.data, ['首页', '拼团', '广告图']);
            SelectedBannerCateId = that.ClassificationListReqID(res.data.data, ['首页', '精选', '广告图']);

            that.getIndexInfo(SpecialPurchaseBannerCateId, SeckillBannerCateId, AssembleBannerCateId, SelectedBannerCateId);
            
            /*that.data.cateIdOne = seasonalGoodsCateId;
            that.data.cateIdTwo = seasonalGoodsTwoCateId;*/
      }
    });
  },
  onReachBottom: function (p) {

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },
  run: function () {
    let vm = this;
    let interval = setInterval(function () {
      if (vm.data.marqueeDistance > -vm.data.length) {
        vm.setData({
          marqueeDistance: vm.data.marqueeDistance - vm.data.marqueePace,
        });
      } else {
        clearInterval(interval);
        vm.setData({
          marqueeDistance: vm.data.windowWidth
        });
        vm.run();
      }
    }, vm.data.intervalTwo);
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
   // clearInterval(this.data.timeer);
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    clearInterval(this.data.timeer);
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    var that = this;
    return {
      title: '小程序',
      path: '/pages/index/index?spid=' + app.globalData.uid,
      // imageUrl: that.data.url + that.data.product.image,
      success: function () {
        wx.showToast({
          title: '分享成功',
          icon: 'success',
          duration: 2000
        })
      }
    }
  }
})