// pages/address/address.js
var app = getApp();
Page({
  data: {
    CustomBar: app.globalData.CustomBar,
    StatusBar: app.globalData.StatusBar,
    _num:'',
    cartId: '',
    pinkId: '',
    couponId: '',
    addressArray:[],
    editAddressFlag: true
  },
  onLoad: function (options) {
    //app.setBarColor();
    if (options.cartId) {
      this.setData({
        cartId: options.cartId,
        pinkId: options.pinkId,
        couponId: options.couponId,
      })
    }
  },
  onShow: function(){
 // this.getAddress();
    this.getAddressTwo();
  },
  tellFun: function(e){
    wx.makePhoneCall({
      phoneNumber: e.currentTarget.dataset.phone //仅为示例，并非真实的电话号码
    });
  },
  goNavaitor: function(e){
    let plugin = requirePlugin('routePlan');
    let key = 'RVABZ-VQPCF-ZAVJS-NMULA-6RPD2-PIBEL';  //使用在腾讯位置服务申请的key
    let referer = '大山科技';   //调用插件的app的名称
    var that = this;
    let endPoint = JSON.stringify({  //终点
      'name': e.currentTarget.dataset.detail,
      'latitude': e.currentTarget.dataset.latitude,
      'longitude': e.currentTarget.dataset.longitude
    });
    wx.navigateTo({
      url: 'plugin://routePlan/index?key=' + key + '&referer=' + referer + '&endPoint=' + endPoint
    });
  },
  getWxAddress:function(){
    var that = this;
     wx.authorize({
       scope: 'scope.address',
       success: function(res) {
         wx.chooseAddress({
           success: function(res) {
             console.log(res);
             var addressP = {};
             addressP.province = res.provinceName;
             addressP.city = res.cityName;
             addressP.district = res.countyName;
             wx.request({
               url: app.globalData.url + '/routine/auth_api/edit_user_address?uid=' + app.globalData.uid + '&openid=' + app.globalData.openid,
               method: 'POST',
               data: {
                 address: addressP,
                 is_default: 1,
                 real_name: res.userName,
                 post_code: res.postalCode,
                 phone: res.telNumber,
                 detail: res.detailInfo,
                 id: 0
               },
               success: function (res) {
                 if (res.data.code == 200) {
                   wx.showToast({
                     title: '添加成功',
                     icon: 'success',
                     duration: 1000
                   })
                   that.getAddress();
                 }
               }
             })
           },
           fail: function(res) {
             if (res.errMsg == 'chooseAddress:cancel'){
               wx.showToast({
                 title: '取消选择',
                 icon: 'none',
                 duration: 1500
               })
             }
           },
           complete: function(res) {},
         })
       },
       fail: function(res) {
         console.log(res);
       },
       complete: function(res) {},
     })
  },
  getAddressTwo: function(){
    var that = this;
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    wx.request({
      url: app.globalData.url + '/routine/auth_api/get_all_address?uid=' + app.globalData.uid + '&xiaoben=true',
      method: 'POST',
      header: header,
      success: function (res) {
        if (res.data.code == 200) {
          that.setData({
            addressArray: res.data.data
          });
        };
      }
    });
  },
  activetapTwo: function (e) {
    var id = e.target.dataset.idx;
    var that = this;

            if (that.data.cartId) {

              var cartId = that.data.cartId;
              var pinkId = that.data.pinkId;
              var couponId = that.data.couponId;
              that.setData({
                cartId: '',
                pinkId: '',
                couponId: '',
              })
              wx.navigateTo({ //跳转至指定页面并关闭其他打开的所有页面（这个最好用在返回至首页的的时候）
                url: '/pages/order-confirm/order-confirm?id=' + cartId + '&addressId=' + id + '&pinkId=' + pinkId + '&couponId=' + couponId
              })
            };
        
  }
})